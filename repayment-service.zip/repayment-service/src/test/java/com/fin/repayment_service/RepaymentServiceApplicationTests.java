package com.fin.repayment_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RepaymentServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
