package com.fin.disbursement_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DisbursementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
